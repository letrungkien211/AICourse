#ifndef IMAGE2MATRIX_HPP
#define IMAGE2MATRIX_HPP

#include <string>

using namespace std;

void Image2Matrix(const string &dirName, const string &imgFileName,
		  const string &outputFileName, int imgNum);


#endif
